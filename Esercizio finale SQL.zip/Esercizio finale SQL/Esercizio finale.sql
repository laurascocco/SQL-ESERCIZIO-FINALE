CREATE DATABASE	LAURASCOCCO;

USE LAURASCOCCO;

/*
Ho deciso di inserire miei dati a piacimento come dice la consegna senza prenderli
da AdventureWorksDW2020.
*/

-- Creo la tabella Product

CREATE TABLE Product (
    ProductID INT,				--PRIMARY KEY avrei potuto scriverlo qui
    ProductName VARCHAR(50),
    ProductCategory VARCHAR(50),
    Available BIT,
	CONSTRAINT PK_Product PRIMARY KEY (ProductID)
);

INSERT INTO Product -- (ProductID, ProductName, ProductCategory, Available)
VALUES
(1, 'Barbie', 'Doll', 1),
(2, 'Mermaid', 'Doll', 1),
(3, 'Lego', 'Building Blocks', 1),
(4, 'Dollhouse Furniture Set', 'Doll', 1),
(5, 'Pokemon cards', 'CCG', 1),
(6, 'The Last of Us 2', 'Videogames', 1),
(7, 'Magic cards', 'CCG', 1),
(8, 'Red Dead Redemption 2', 'Videogames', 1),
(9, 'Playstation 5', 'Console', 1),
(10, 'Dinosaur Puzzle', 'Puzzle Games', 0),
(11, 'Xbox360', 'Console', 1),
(12, 'Red Dead Redemption 1', 'Videogames', 1),
(13, 'The Last of Us 1', 'Videogames', 1),
(14, 'Nintendo Switch', 'Console', 1);

SELECT *
FROM Product

/*
Qui avrei potuto creare una tabella separata per le categorie 
dei prodotti e collegarla alla tabella Product attraverso una 
relazione uno-a-molti, evitando la ridondanza delle informazioni
di categoria all'interno della tabella Product.
Oppure avrei potuto creare una tabella come quella che ora 
creer� per la tabella Region in modo da poter utilizzare la selfjoin.
*/

-- Creo la tabella Region 

CREATE TABLE Region (
    StateID INT, -- PRIMARY KEY
    StateName VARCHAR(25),
    RegionID INT,
	CONSTRAINT PK_Region PRIMARY KEY (StateID)
);

INSERT INTO Region -- (StateID, StateName, RegionID)
VALUES 
(1, 'Europe', NULL),
(2, 'North America', NULL),
(3, 'Asia', NULL),
(4, 'Italy', 1),
(5, 'Spain', 1),
(6, 'France', 1),
(7, 'Canada', 2),
(8, 'China', 3),
(9, 'Japan', 3);

SELECT *
FROM Region

/*
Anche qui avrei potuto creare un'altra tabella uno-a-molti separata tra Region e State.
Visto che nella consegna � stato richiesto di creare 3 entit� sono rimasta in linea con 
queto, per� per minimizzare probabilmente i dati avrei creato la tabella Category
e la tabella State.
*/

-- Creo la tabella Sales

CREATE TABLE Sales (
    SalesID INT, -- PRIMARY KEY
    ProductID INT,
    StateID INT,
    OrderDate DATE,
    Quantity INT,
    UnitPrice DECIMAL(10, 2),
    SalesAmount DECIMAL(10, 2),
	CONSTRAINT PK_Sales PRIMARY KEY (SalesID),
	CONSTRAINT FK_Sales_Product FOREIGN KEY (ProductID) REFERENCES Product(ProductID),
	CONSTRAINT FK_Sales_Region FOREIGN KEY (StateID) REFERENCES Region(StateID)
);

INSERT INTO Sales -- (SalesID, ProductID, StateID, OrderDate, Quantity, UnitPrice, SalesAmount)
VALUES 
(1, 1, 5, '2022-03-15', 2, 10, 20),
(2, 3, 6, '2022-05-20', 1, 20.5, 25.5),
(3, 5, 7, '2022-08-10', 3, 3.5, 10.5),
(4, 6, 8, '2022-11-05', 1, 60, 60),
(5, 9, 8, '2023-02-28', 1, 500, 500),
(6, 11, 8, '2023-05-12', 2, 200.5, 401),
(7, 2, 9, '2023-08-03', 1, 15.5, 15.5),
(8, 13, 4, '2023-10-22', 1, 50, 50),
(9, 14, 4, '2023-12-18', 1, 300.5, 300.5),
(10, 7, 5, '2023-02-08', 2, 6, 12),
(11, 4, 6, '2023-05-17', 1, 30, 30),
(12, 14, 5, '2024-01-29', 2, 300.5, 601),
(13, 6, 4, '2022-10-15', 1, 60, 60);

SELECT *
FROM Sales

-- Task 4

-- 1) Verifica che i campi definiti come PK siano univoci.

SELECT ProductID, COUNT(*) AS Counting
FROM Product
GROUP BY ProductID
HAVING COUNT(*) > 1;

-- essendo il risultato una tabella vuota significa che nessun dato � stato inserito 
-- pi� di 1 volta e che quindi � unico

SELECT StateID, COUNT(*) AS Counting
FROM Region
GROUP BY StateID
HAVING COUNT(*) > 1;

SELECT SalesID, COUNT(*) AS Counting
FROM Sales
GROUP BY SalesID
HAVING COUNT(*) > 1;

/*
2)	Esporre l�elenco delle transazioni indicando nel result set il codice documento, la data, 
	il nome del prodotto, la categoria del prodotto, il nome dello stato, il nome della regione
	di vendita e un campo booleano valorizzato in base alla condizione che siano passati pi� 
	di 180 giorni dalla data vendita o meno (>180 -> True, <= 180 -> False)
*/

-- self join

SELECT 
    r1.StateName AS StateName,
    r2.StateName AS RegionName
FROM 
	Region r1
	JOIN Region r2 
	ON r1.RegionID = r2.StateID;

-- risposta alla domanda

SELECT
    s.SalesID,
    s.OrderDate,
    p.ProductName,
    p.ProductCategory,
    r1.StateName AS StateName,
    r2.StateName AS RegionName,
    CASE WHEN DATEDIFF(DAY, s.OrderDate, GETDATE()) > 180 THEN 1 
	ELSE 0 
	END AS MoreThan180Days
FROM 
	Sales AS s
	JOIN Product AS p
	ON s.ProductID = p.ProductID
	JOIN Region r1 
	ON s.StateID = r1.StateID
	JOIN Region r2 
	ON r1.RegionID = r2.StateID
ORDER BY 
	MoreThan180Days DESC, s.OrderDate;

/*
3)	Esporre l�elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno. 
*/

SELECT
    p.ProductID,
    p.ProductName,
	p.ProductCategory, -- si pu� anche non mettere(sia qui che in GROUP BY)
    YEAR(s.OrderDate) AS SalesYear,
    SUM(s.SalesAmount) AS TotalAmount
FROM 
	Product AS p
	JOIN Sales AS s
	ON p.ProductID = s.ProductID
GROUP BY
    p.ProductID, p.ProductName, p.ProductCategory, YEAR(s.OrderDate)
ORDER BY
	p.ProductID, YEAR(s.OrderDate), TotalAmount;

-- 4) Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente.

SELECT
    r.StateName,
    YEAR(s.OrderDate) AS SalesYear,
    SUM(s.SalesAmount) AS TotalAmount
FROM 
	Sales AS s
	JOIN Region AS r
	ON s.StateID = r.StateID
GROUP BY
    r.StateName, YEAR(s.OrderDate)
ORDER BY
    SalesYear DESC, TotalAmount DESC;

-- 5) Rispondere alla seguente domanda: qual � la categoria di articoli maggiormente richiesta dal mercato?

SELECT TOP 1
    p.ProductCategory,
    COUNT(*) AS NumberSales
FROM 
	Product AS p
	JOIN Sales AS s
	ON p.ProductID = s.ProductID
GROUP BY
    p.ProductCategory
ORDER BY
    NumberSales DESC;

-- 6)	Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? 
--		Proponi due approcci risolutivi differenti.

-- PRIMO APPROCCIO

SELECT * -- mi vengono mostrati tutti gli attributi in questo caso di Product e Sales perch� ho fatto una join
FROM 
	Product AS p
	LEFT JOIN Sales AS s
	ON p.ProductID = s.ProductID
WHERE
    s.SalesID IS NULL;

-- SECONDO APPROCCIO

SELECT *
FROM 
	Product AS p
WHERE p.ProductID NOT IN 
	(
    SELECT ProductID		-- query innestata indipendente (che funziona anche da sola)
    FROM Sales
);

--7) Esporre l�elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita pi� recente).

SELECT
    p.ProductID,
    p.ProductName,
    MAX(s.OrderDate) AS LastSaleDate
FROM 
	Product AS p
	LEFT JOIN Sales AS s
	ON p.ProductID = s.ProductID
GROUP BY
    p.ProductID, p.ProductName
HAVING
    MAX(s.OrderDate) IS NOT NULL;

-- Oppure cos�

SELECT
    p.ProductID,
    p.ProductName,
    s1.OrderDate AS LastSaleDate
FROM 
    Product AS p
	JOIN Sales AS s1
	ON p.ProductID = s1.ProductID
WHERE
    s1.OrderDate = (SELECT MAX(s2.OrderDate) FROM Sales AS s2 WHERE s2.ProductID = p.ProductID);

-- 8)	Creare una vista sui prodotti in modo tale da esporre una �versione denormalizzata� 
-- delle informazioni utili (codice prodotto, nome prodotto, nome categoria)

/*
Sono gi� quasi le informazioni che ho io, non ho avuto tempo di aggiungere molte colonne/attributi.
Se avessi fatto anche questa come la tabella Region avrei dovuto fare una selfjoin,
mentre se avessi creato una tabella Category, avrei dovuto fare join con quella per tirare fuori il nome della categoria.
Se avessi utilizzato AdventureWorksDW2020 avrei molti pi� attributi e quindi questa view avrebbe pi� senso.
*/

CREATE VIEW Product2 AS (
SELECT
    p.ProductID,
    p.ProductName,
    p.ProductCategory
FROM 
	Product AS p
	);

SELECT *
FROM Product2

-- 9) Creare una vista per restituire una versione �denormalizzata� delle informazioni geografiche

CREATE VIEW InfoGeo AS (
SELECT
    R1.StateID,
    R1.StateName,
    R2.StateName AS RegionName
FROM 
	Region R1
	JOIN Region R2 
	ON R1.RegionID = R2.StateID);

SELECT *
FROM InfoGeo

/*
Avrei potuto fare due entit� simili, Sales da Reseller e Sales da Internet, come AdventureWorksDW2020 per poter poi impostare una 
UNION come abbiamo fatto spesso negli esercizi ma me ne sono ricordata alla fine e non ho pi� tempo
per rifare tutto
La differenza fra UNION e UNION ALL � che UNION ALL prende tutti i dati mentre UNION toglie i duplicati
Altra cosa che abbiamo imparato con le UNION � che, se si cerca di unire due attributi che non sono in entrambe 
le tabelle, bisogna mettere per esempio il primo attributo che fa riferimento ad un null e poi un null che fa riferimento 
all'attributo dell'altra tabella. Infine si rinominano i null con l'attributo di riferimento.
Con le UNION abbiamo anche imparato ad inserire la colonna 'Flag', abbinando due colonne diverse ma rinominandole con lo stesso
nome visto che fanno riferimento a valori di diverse righe (che come filtro fatto in Excel con la PivotTable sarebbe stato utile).
*/

-- Per il punto 10 mi verrebbe da creare una vista denormalizzata con Sales per poter poi in Power Query
-- avere una connessione tra le due viste sopra

CREATE VIEW Sales2 AS (
SELECT
    SalesID,
    ProductID,
	StateID,
    Quantity,
    UnitPrice,
    SalesAmount,
	OrderDate
FROM 
    Sales);

SELECT *
FROM Sales2
